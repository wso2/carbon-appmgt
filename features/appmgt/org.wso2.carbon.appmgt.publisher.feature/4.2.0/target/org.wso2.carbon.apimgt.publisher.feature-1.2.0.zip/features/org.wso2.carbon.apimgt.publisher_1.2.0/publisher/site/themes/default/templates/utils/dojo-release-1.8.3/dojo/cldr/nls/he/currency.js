/*
	Copyright (c) 2004-2012, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/he/currency",{"HKD_displayName":"דולר הונג קונגי","CHF_displayName":"פרנק שוויצרי","CAD_displayName":"דולר קנדי","CNY_displayName":"יואן רנמינבי סיני","AUD_displayName":"דולר אוסטרלי","JPY_displayName":"ין יפני","USD_displayName":"דולר אמריקאי","GBP_displayName":"לירה שטרלינג","EUR_displayName":"אירו"});
